<?php

// Paths
define('DENGRU_CORE_PATH', dirname(__FILE__) . '/core');
define('DENGRU_MANAGER_PATH', dirname(__FILE__) . '/manager');
define('DENGRU_MANAGER_URL', '/manager');
define('DENGRU_TEMPLATE_PATH', DENGRU_CORE_PATH . '/tpl');

// Database
define('DB_HOST', 'localhost');
define('DB_NAME', 'degrun');
define('DB_USER', 'degrun');
define('DB_PASS', 'eKcGZr59zAa2BEWU');

define('SQLITE_FILE', './test.sdb');

// Debugging
define('DEBUG', true);

// Session constants
define('_SESSION_SALT', $_SERVER['HTTP_HOST']);
define('_SESSION_NAME', preg_replace('#[^a-z0-9]#i', '', $_SERVER['HTTP_HOST']));
define('_SESSION_DIR', str_replace('.', '_', $_SERVER['HTTP_HOST']) . '_sessiondata');

?>