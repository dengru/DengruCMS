<?php
/**
 * Manager Service
 * 
 * Validates and handles requests & inputs made by admins
 * 
 * @author 	Dennis Grundelius
 */
@include_once(dirname(dirname(__FILE__)) . '/config.core.php');
require_once(DENGRU_CORE_PATH . '/models/Manager.php');

class ManagerService extends Manager {
	
	/**
	 * Create Page Object
	 * 
	 * @param unknown_type $values
	 */
	public function createPage($values) {
		$pagetitle = $values['pagetitle'];
		$alias = $values['alias'];
		$content = $values['content'];
		$author = $values['author'];
		//$created
		//$modified
		$active = $values['active'];
		$description = $values['description'];
		
		return $this->page->insert(array(
				'pagetitle' => $pagetitle,
				'alias' => $alias,
				'content' => $content,
				'author' => $author,
				'active' => $active,
				'description' => $description
		));
	}
	
	/**
	 * Update Page Object
	 * 
	 * (non-PHPdoc)
	 * @see Page::update()
	 */
	public function updatePage($values) {
		$pagetitle = $values['pagetitle'];
		$alias = $values['alias'];
		$content = $values['content'];
		$author = $values['author'];
		//$created
		//$modified
		$active = $values['active'];
		$description = $values['description'];
		
		$updates = array();
		
		if ($pagetitle) {
			$updates['pagetitle'] = $pagetitle;
		}
		
		if ($alias) {
			$updates['alias'] = $alias;
		}
		
		if ($content) {
			$updates['content'] = $content;
		}
		
		if ($author) {
			$updates['author'] = $author;
		}
		
		if ($active) {
			$updates['active'] = $active;
		}
		
		if ($description) {
			$updates['description'] = $description;
		}
		
		$this->page->update($this->page->id, $updates);
		
		return true;
	}
}
?>