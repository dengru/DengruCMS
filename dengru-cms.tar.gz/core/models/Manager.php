<?php
/**
 * Manager
 * 
 * @author Dennis Grundelius
 */
require_once(DENGRU_CORE_PATH . '/models/User.php');
require_once(DENGRU_CORE_PATH . '/models/Page.php');

class Manager extends Dengru {
	
	public $user;
	public $page;
	public $pagetitle;
	
	private $_action;
	
	function __construct() {
		parent::getDb(); //The getDb function is called from the parent class 'Dengru'
		$this->user = new User();
		$this->page = new Page();
	}
	
	private function _getAction() {
		$this->_action = isset($_GET['a']);
		switch ($this->_action) {
			case 'edit-account':
				$this->pagetitle = 'Edit Account';
				$this->user->edit_user();
				@include_once(DENGRU_CORE_PATH . '/templates/manager.editaccount.tpl.php');
				if (isset($_POST['save-changes'])) {
					$this->user->update_user();
				}
				break;
		}
	}
	
	public function initialize() {
		if ($this->user->isAdmin()) {
			$this->_getAction();
		}
	}
	
	public function page_form() {
	?>
		<form method="POST">
			<div class="field">
				<label for="pagetitle">Pagetitle:</label>
				<input type="text" for="pagetitle" name="page[pagetitle]" value="<?php echo $page->pagetitle ?>" />
			</div>
			<div class="field">
				<label for="alias">Alias:</label>
				<input type="text" for="alias" name="page[alias]" value="<?php echo $page->alias ?>" />
			</div>
			<div class="field">
				<label for="content">Content:</label>
				<textarea for="content" name="page[content]"><?php echo $page->content ?></textarea>
			</div>
			<div class="field">
				<label for="description">Description:</label>
				<textarea for="description" name="page[description]"><?php echo $page->description ?></textarea>
			</div>
			<div class="field">
				<input type="submit" name="save_page" />
			</div>
		</form>
	<?php 
	}

	function new_page() {
		?>
		<h2>New Document</h2>
		<?php
		require_once(dirname(__FILE__) . '/Page.php');
		
		$this->page_form();//call the form
		
		if (isset($_POST['save_page'])) {
			$page = new Page($_POST['page']);
			$stmt = $this->prepare("INSERT INTO `pages` (`pagetitle`, `alias`, `content`, `description`) VALUES (:pagetitle, :alias, :content, :description)");
			
			if ($stmt->execute(array(
					'pagetitle' => $page->pagetitle,
					'alias' => $page->alias,
					'content' => $page->content,
					'description' => $page->description
			))) {
				header("Location: index.php");
			}
			else {
				$page = new Page;
			}
		}
	}
	
	function edit_page() {
		?>
		<h2>Edit Document</h2>
		<?php
		require_once(dirname(__FILE__) . '/Page.php');
		
		$this->page_form();
		
		if (!isset($_GET['id']))
			header("Location: index.php");
		
		if (!isset($_POST['save_page'])) {
			$stmt = $this->prepare("SELECT `id`, `pagetitle`, `alias`, `content`, `description` FROM `pages` WHERE `id` = :id");
			$stmt->execute(array(
					'id' => $_GET['id']
			));
			
			$page = $stmt->fetchObject('Page');
		}
		else {
			$stmt = $this->prepare("UPDATE `pages` SET `pagetitle` = :pagetitle, `alias` = :alias, `content` = :content, `description` = :description WHERE `id` = :id");
			if ($stmt->execute($_POST['page'] + array('id' => $_GET['id']))) {
				header("Location: index.php");
			}
			else {
				echo "<p>Failed to update the page</p>";
			}
		}
	}
	
	function delete_page() {
		if (!isset($_GET['id'])) {
			header("Location: index.php");
		}
		
		$stmt = $this->prepare("DELETE FROM `pages` WHERE `id` = :id");
		
		if ($stmt->execute(array(
				'id' => $_GET['id']
		))) {
			header("Location: index.php");
		}
		
		echo "failed to delete the item";
	}
}
?>