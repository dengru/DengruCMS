<?php
/**
 * Request
 * 
 * @desc: Handles user requests (form submissions, logins, logouts etc)
 * @author Dennis Grundelius
 */

@include_once(dirname(dirname(__FILE__)) . '/config.core.php');
require_once(DENGRU_CORE_PATH . '/services/user.service.php');
//require_once(DENGRU_CORE_PATH . '/services/manager.service.php');
require_once(DENGRU_CORE_PATH . '/services/page.service.php');

class Request {
	
	public $userService;
	//public $managerService;
	public $pageService;
	
	public function __construct() {
		
		$this->userService = new UserService();
		//$this->managerService = new ManagerService();
		$this->pageService = new PageService();
		
		if (isset($_POST['login'])) {
			$this->userService->login($_POST);
		}
		else if (isset($_POST['register'])) {
			$this->userService->register($_POST);
		}
		else if (isset($_POST['update-profile'])) {
			$this->userService->update($_POST);
		}
		else if (isset($_GET['logout']) && $this->userService->isLoggedIn == true) {
			$this->userService->logout();
		}
		
		/* Manager requests */
		else if (isset($_POST['update-page']) && $this->user->isAdmin()) {
			//$this->managerService->updatePage($_POST);
		}
		else if (isset($_POST['create-page']) && $this->user->isAdmin()) {
			//$this->managerService->createPage($_POST);
		}
		else if (isset($_POST['delete-page']) && $this->user->isAdmin()) {
			//$this->managerService->deletePage();
		}
		else {
			$this->parseRequest();
		}
	}
	
	public function parseRequest() {
		/* Page requests by "?action=x" */
		if (isset($_GET['action']) && (!isset($_GET['id']))) {
			if ($_GET['action'] == 'account-settings') {
				//$this->userService->getUser($this->userService->id);
				if ($this->userService->isLoggedIn() == true) {
					$this->pageService->editAccount();
				} 
				else {
					$this->pageService->errorForbidden();
				}
			}
			else if ($_GET['action'] == 'account') {
				if ($this->userService->isLoggedIn() == true) {
					$this->pageService->viewAccount();
				} 
				else {
					$this->pageService->errorForbidden();
				}
			}
			else if ($_GET['action'] == 'login') {
				//@todo: login form visible based on user authentication
				if ($this->userService->isLoggedIn() == false) {
					$this->pageService->login();
				}
			}
			else if ($_GET['action'] == 'register') {
				$this->pageService->register();
			}
		}
		/* Page requests by "?id=x" */
		else if (isset($_GET['id']) && (!isset($_GET['action']))) {
			if ($this->pageService->isPageReal((int)($_GET['id']))) {
				$this->pageService->getPage((int)($_GET['id']));
			}
			else {
				$this->pageService->errorNotFound(); //call this if the requested page was not found
			}
		}
	}
}
?>