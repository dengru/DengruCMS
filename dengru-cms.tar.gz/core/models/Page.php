<?php
/**
 * Page
 * 
 * @author 	Dennis Grundelius
 */
require_once(DENGRU_CORE_PATH . '/models/User.php');

class Page extends Dengru {
	
	public $id;
	public $pagetitle = null;
	public $alias;
	public $content;
	public $author;
	public $created;
	public $modified;
	public $active;
	public $description;

	
	public function __construct() {	
		parent::getDb(); //The getDb function is called from the parent class 'Dengru'
	}
	
	/**
	 * Get Page
	 */
	public function getPageContents($id) {
		try {
			$stmt = parent::prepare("SELECT `id`, `pagetitle`, `alias`, `content`, `description` FROM `pages` WHERE `id` = :id LIMIT 1");
			$stmt->execute(array('id' => $id));
			
			$this->pageVars = $stmt->fetchObject('Page');
		}
		catch (PDOException $e) {
			echo $e->getMessage();
		}
	}
	
	/**
	 * Is Page Real
	 * 
	 * @param unknown_type $id
	 */
	public function isPageReal($id) {
		$stmt = $this->prepare("SELECT `id` FROM `pages` WHERE `id` = :id LIMIT 1 ");
		$stmt->bindParam(':id', $id);
		$stmt->execute();
		
		return ($stmt->rowCount() > 0);
	}
	
	
	/* Manager functions */
	
	public function update() {
		
	}
	
	public function delete() {
		
	}
	
	public function insert() {
		
	}
	
}
?>