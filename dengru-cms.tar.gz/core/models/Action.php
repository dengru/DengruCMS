<?php
/**
 * Action
 * 
 * @author 	Dennis Grundelius
 */

class Action extends Dengru {
	
	public function __construct() {
	//	if ($this->user->isLoggedIn() == true) {
			if ($_GET['action'] == 'edit-settings') {
				echo 'Lol';
			}
			if ($_GET['action'] == 'profile') {
				echo 'Hahahah';
			}
			
			else if ($_GET['action'] == '')
	//	}
	}
	
	public function loadAction() {

		if (isset($_GET['a']) && !isset($_GET['id'])) {
			switch ($_GET['a']) {
				case 'login':
					if ($this->user->isLoggedIn() == false) {
						$this->pagetitle = 'Login';
						@include_once(DENGRU_CORE_PATH . '/templates/login.tpl.php');
						if (isset($_POST['go'])) {
							$this->user->login($_POST['username'], $_POST['password']);
						}
					}
					break;
						
				case 'profile':
					$this->pagetitle = 'Profile';
					break;
						
				case 'edit-settings':
					if ($this->user->isLoggedIn() == true) {
						$this->pagetitle = 'Edit Settings';
						$values = $this->user->getUser();
						print_r($values);
						@include_once(DENGRU_CORE_PATH . '/templates/edit.settings.tpl.php');
						if (isset($_POST['save-changes'])) {
							$this->user->update($_SESSION['uid'], $values);
						}
						if (isset($_POST['change-password'])) {
							$this->user->changePassword($_POST['oldPassword'], $_POST['newPassword']);
						}
					}
					break;
						
				default:
					echo 'HOLD IT!';
			}
		}
		else if (!isset($action) && isset($_GET['id'])) {
			$this->getPage();
		}
	}
}