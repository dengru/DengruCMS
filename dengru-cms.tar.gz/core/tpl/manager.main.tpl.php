<?php @include_once(dirname(dirname(__FILE__)) . '/templates/manager.header.tpl.php'); ?>
			<div class="right-container">
				<h3>Welcome</h3>
				<p>This is the main manager page.</p>
			</div>
<?php @include_once(dirname(dirname(__FILE__)) . '/templates/manager.footer.tpl.php'); ?>