</div>
	</div>
	
	<div class="footer-container">
		<footer class="wrapper">
			<h3><?php echo $dengru->settings->site_name; ?></h3>
		</footer>
	</div>
	
	<script src="/assets/static/js/modernizr-2.6.2.js"></script>
</body>
</html>