			<div id="error">
				<h1><?php echo $this->_errorTitle; ?></h1>
				<div class="msg">
					<p><?php echo $this->_errorMsg; ?></p>
				</div>
			</div>