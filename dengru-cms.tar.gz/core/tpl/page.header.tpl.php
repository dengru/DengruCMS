<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	
	<title><?php echo $this->_pagetitle; ?></title>
	
	<link href="assets/static/css/main.css" rel="stylesheet">
</head>
<body>

	<div class="header-container">
		<header class="wrapper clearfix">
			<h1 class="title"><?php echo $this->_pagetitle; ?></h1>
			<nav>
				<ul>
					<li><a href="#">nav ul li a</a></li>
					<li><a href="#">nav ul li a</a></li>
					<li><a href="#">nav ul li a</a></li>
					<li><a href="#">nav ul li a</a></li>
				</ul>
			</nav>
		</header>
	</div>
	
	<div class="main-container">
		<div class="main wrapper clearfix">