			<div>
				<h1>Login</h3>
				<form id="account-login" class="form" action="" method="post">
					<fieldset>
						<div>
							<label>Username:</label> <input name="username" type="text" placeholder="enter a username.." />
						</div>
						<div>
							<label>Password:</label> <input name="password" type="password" placeholder="enter a password.." />
						</div>
						<div style="float: right;">
							<button class="button" type="submit" name="login">login &gt;</button>
						</div>
					</fieldset>
				</form>
			</div>