-- phpMyAdmin SQL Dump
-- version 3.5.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 18, 2013 at 09:21 AM
-- Server version: 5.5.28-0ubuntu0.12.10.2
-- PHP Version: 5.4.6-1ubuntu1.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `degrun`
--

-- --------------------------------------------------------

--
-- Table structure for table `chunks`
--

CREATE TABLE IF NOT EXISTS `chunks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(75) NOT NULL,
  `content` longtext NOT NULL,
  `description` tinytext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `description` tinytext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'Administrators', 'Master group, members of this group have full access to the site''s features, including editing of other members profiles and more.'),
(2, 'Normal Users', 'This is the default user group. Members of this group have limited access to the site. Members of the ''Normal Users'' user group does not have access to the site''s backend.');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `pagetitle` varchar(120) NOT NULL,
  `alias` varchar(120) NOT NULL,
  `content` longtext NOT NULL,
  `author` varchar(75) NOT NULL,
  `created` date NOT NULL,
  `modified` date NOT NULL,
  `active` int(10) NOT NULL DEFAULT '0',
  `description` tinytext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `pagetitle`, `alias`, `content`, `author`, `created`, `modified`, `active`, `description`) VALUES
(1, 'Test page', 'test-page', 'This is a testing page of my content management system project. The page is dynamic. You didn''t know that right?', '', '0000-00-00', '0000-00-00', 0, 'This is a description of this page, do you like it? I know it''s not plenty of text but still..');

-- --------------------------------------------------------

--
-- Table structure for table `templates`
--

CREATE TABLE IF NOT EXISTS `templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(75) NOT NULL,
  `content` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(75) NOT NULL,
  `email` varchar(75) NOT NULL,
  `group_id` int(11) NOT NULL DEFAULT '2',
  `address` varchar(100) NOT NULL,
  `phone` int(50) NOT NULL,
  `password` varchar(40) NOT NULL,
  `pattern` varchar(22) NOT NULL,
  `salt1` varchar(12) NOT NULL,
  `salt2` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `group_id`, `address`, `phone`, `password`, `pattern`, `salt1`, `salt2`) VALUES
(22, 'admin', '', 2, '', 0, 'b8c91161b0d38ccd43680a70847ce186ee82e827', '{salt1}.{salt2}.{pass}', ')bA#W_w@J2_@', 'x4?b~7p90V'),
(23, 'admin', '', 2, '', 0, 'b1ce605e8a361842847b77fcf476a59a87da33c8', '{salt1}.{salt2}.{pass}', '*_2:yEJLRSYl', '9Pp3?c]Pxv'),
(24, 'admin', '', 2, '', 0, 'f54b9fcfe1796a9119723064bdf0bae952204052', '{salt1}.{salt2}.{pass}', 'Lq_!>@WQ2Kle', '6Cbc2?~P4c'),
(25, 'Hello', '', 2, '', 0, 'a149995f0817c0afd723d3cf50f57c0efffaaab6', '{salt1}.{salt2}.{pass}', 'k#._T(:,w2%t', 'C4}B7[`0}`'),
(26, 'MrMister', '', 2, '', 0, 'baf65d60a57e432005f4df84e49db6694b1977d3', '{salt1}.{salt2}.{pass}', '=JY=&y%Kkd6T', 'v2BpxVV4}8'),
(27, 'Admiral', 'myemail@somesite.com', 1, 'Furustigen 8A', 871621541, 'f86b07f131cecfac039153fc0f63c4d95882e0f9', '{salt1}.{salt2}.{pass}', '-**e.B:BE$A6', 'xc0~P~pc1{');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
